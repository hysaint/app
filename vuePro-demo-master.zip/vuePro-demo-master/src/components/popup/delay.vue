<template>
	<div class="delayTime"></div>
</template>