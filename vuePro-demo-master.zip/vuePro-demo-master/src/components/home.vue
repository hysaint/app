<template>
	<router-view></router-view>
</template>
<style>
	@import '../assets/css/style2016.css';
	@import '../assets/css/transition.css';
</style>