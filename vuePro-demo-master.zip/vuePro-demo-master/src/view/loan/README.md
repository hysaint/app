#文件说明
借款模块

```pre

├── cancelSup.vue           // 取消上标
├── dataComm.vue            // 填写资料-通用
├── dataMust.vue            // 填写资料-必填
├── dataSelect.vue          // 填写资料-选填
├── des.vue                 // 借款描述
├── index.vue               // 首页
├── loanLarge.vue           // 福利借款
├── loanMicro.vue           // 微额借款
├── loanSmall.vue           // 小额借款
├── recom.vue               // 推荐人联系号码
├── submitApply.vue         // 填写申请借款
├── sureMore.vue            // 确认借款详情-更多
├── sureMsg.vue             // 确认贷款详情

```
