#文件说明
其它模块：登录、404等

```pre

├── agreement.vue       // 协议页面
├── error.vue           // 404
├── forget.vue          // 忘记密码
├── login.vue           // 登录
├── reg.vue             // 注册

```
