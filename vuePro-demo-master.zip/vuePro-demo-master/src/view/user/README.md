#文件说明
个人中心模块

```pre

├── aboutUs.vue                 // 关于我们
├── borrowDetail.vue            // 借款详情-正常
├── borrowDmore.vue             // 借款详情-更多
├── borrowList.vue              // 我的借款列表切换-父组件
├── borrowListAll.vue           // 我的借款-全部
├── borrowListApply.vue         // 我的借款-申请中
├── borrowListOver.vue          // 我的借款-已结束
├── borrowListRepay.vue         // 我的借款-待归还
├── borrowReason.vue            // 借款-不过理由
├── dealDetail.vue              // 借款合同详情
├── dealList.vue                // 借款合同列表
├── feedback.vue                // 意见反馈
├── helpDetail.vue              // 帮助中心-详情
├── helpList.vue                // 帮助中心-列表
├── index.vue                   // 首页
├── repayGo.vue                 // 进行还款
├── repayList.vue               // 我的还款列表
├── repayRecord.vue             // 还款记录
├── repayTips.vue               // 还款成功提示
├── rewardList.vue              // 我的奖励列表切换-父组件
├── rewardUnused.vue            // 我的奖励-未使用
├── rewardUsed.vue              // 我的奖励-已使用
├── rewardExpired.vue           // 我的奖励-已过期

```
