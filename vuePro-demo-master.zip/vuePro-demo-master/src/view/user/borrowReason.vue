<template>
  <div class="container">
    <topComponent title='查看理由'></topComponent>
    <div class="seeReason">
      <dl>
        <dt class="col6">审核不通过理由</dt>
        <dd>本人取消订单。</dd>
      </dl>
    </div>
  </div>
</template>
