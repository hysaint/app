<template>
  <div class="container">
    <topComponent title='征信报告详情'></topComponent>
    <dl class="reportDetail">
      <dt>查询编号：123456787</dt>
      <dd>
        <p><span>发放机构</span>中国银行资阳支行</p>
        <p><span>发放日期</span>2012-05-28</p>
        <p><span>发放金额</span>330000</p>
        <p><span>账户类型</span>人民币</p>
        <p><span>贷款类型</span>个人住房贷款</p>
        <p><span>到期日期</span>2022-05-28</p>
        <p><span>截止日期</span>2015-04-01</p>
        <p><span>是否逾期</span>否</p>
        <p><span>余额</span>257357</p>
        <p><span>近五年内逾期数</span>0</p>
        <p><span>近五年内逾期超过90天数</span>0</p>
        <p><span>结清日期</span></p>
        <p><span>逾期金额</span></p>
        <p><span>状态</span></p>
        <p><span>状态发生时间</span></p>
      </dd>
    </dl>
    <dl class="reportDetail mt20">
      <dt>查询编号：123456787</dt>
      <dd>
        <p><span>发放机构</span>中国银行资阳支行</p>
        <p><span>发放日期</span>2012-05-28</p>
        <p><span>发放金额</span>330000</p>
        <p><span>账户类型</span>人民币</p>
        <p><span>贷款类型</span>个人住房贷款</p>
        <p><span>到期日期</span>2022-05-28</p>
        <p><span>截止日期</span>2015-04-01</p>
        <p><span>是否逾期</span>否</p>
        <p><span>余额</span>257357</p>
        <p><span>近五年内逾期数</span>0</p>
        <p><span>近五年内逾期超过90天数</span>0</p>
        <p><span>结清日期</span></p>
        <p><span>逾期金额</span></p>
        <p><span>状态</span></p>
        <p><span>状态发生时间</span></p>
      </dd>
    </dl>
  </div>
</template>
