<template>
  <div class="container">
    <topComponent title='如何注册账号'></topComponent>
    <div class="reportRegStep">
      <p>第一步：用电脑打开网址：<br><span class="blue">https://ipcrs.pbccrc.org.cn/</span>点击“马上开始"</p>
      <i class="icon01">注册步骤示例图1</i>
      <p>第二步：点击"新用户注册"</p>
      <i class="icon02">注册步骤示例图2</i>
      <p>第三步：填写身份信息、验证码，阅读服务协议，点击"下一步"</p>
      <i class="icon03">注册步骤示例图3</i>
      <p>第四步：填写用户基本信息，然后点击"提交"</p>
      <i class="icon04">注册步骤示例图4</i>
      <p>第五步：注册完成，页面提示用户注册成功</p>
      <i class="icon05">注册步骤示例图5</i>
      <p>注册完成之后，即可使用登录名及密码在{{appName}}APP内登录</p>
    </div>
  </div>
</template>
