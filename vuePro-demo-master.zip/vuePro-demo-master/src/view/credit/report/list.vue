<template>
  <div class="container">
    <topComponent title='征信报告详情'></topComponent>
    <dl class="reportDllist">
      <dt>担保记录<i class="blue">2条</i></dt>
      <dd class="iconTrue">2014年1月17日中国农业银行发放的贷记卡(人民币账户)。截至 2015年6月，信用额度34,00,已使用额度32,752。</dd>
      <dd class="iconTrue">2014年1月17日中国农业银行发放的贷记卡(人民币账户)。截至 2015年6月，信用额度34,00,已使用额度32,752。</dd>
    </dl>
    <dl class="reportDllist mt20">
      <dt>逾期记录<i class="blue">1条</i></dt>
      <dd class="iconSign">2014年1月17日中国农业银行发放的贷记卡(人民币账户)。截至 2015年6月，信用额度34,00,已使用额度32,752。</dd>
      <dd class="iconSign">2014年1月17日中国农业银行发放的贷记卡(人民币账户)。截至 2015年6月，信用额度34,00,已使用额度32,752。</dd>
    </dl>
    <dl class="reportDllist mt20">
      <dt>透支记录<i class="col9">未记录</i></dt>
    </dl>
    <dl class="reportDllist mt20">
      <dt>其它记录<i class="blue">3条</i></dt>
      <dd>2014年1月17日中国农业银行发放的贷记卡(人民币账户)。截至 2015年6月，信用额度34,00,已使用额度32,752。</dd>
      <dd>2014年1月17日中国农业银行发放的贷记卡(人民币账户)。截至 2015年6月，信用额度34,00,已使用额度32,752。</dd>
      <dd>2014年1月17日中国农业银行发放的贷记卡(人民币账户)。截至 2015年6月，信用额度34,00,已使用额度32,752。</dd>
    </dl>
  </div>
</template>
