<template>
  <div class="container">
    <topComponent title='查看支持银行'></topComponent>
    <dl class="supportBank">
      <dt>现支持的银行</dt>
      <dd class="bank30">农业银行</dd>
      <dd class="bank90">北京银行</dd>
      <dd class="bank40">中国银行</dd>
      <dd class="bank60">建设银行</dd>
      <dd class="bank100">光大银行</dd>
      <dd class="bank110">兴业银行</dd>
      <dd class="bank120">民生银行</dd>
      <dd class="bank130">中信银行</dd>
      <dd class="bank150">广发银行</dd>
      <dd class="bank20">工商银行</dd>
      <dd class="bank70">邮政储蓄银行</dd>
      <dd class="bank50">浦发银行</dd>
      <dd class="bank140">平安银行</dd>
      <dd class="bank160">华夏银行</dd>
      <dd class="bank10">招商银行</dd>
      <dd class="bank80">交通银行</dd>
    </dl>
  </div>
</template>
