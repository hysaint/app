#文件说明
信用模块

```pre

├── report                  // 央行征信[未开发，不进行介绍]
├── alipay.vue              // 支付宝认证[未开发]
├── bankDetail.vue          // 银行卡详情
├── bankHelp.vue            // 银行卡帮助
├── bankInfo.vue            // 银行卡信息
├── bankSMS.vue             // 短信验证添加银行卡
├── checkIDcard.vue         // 身份证认证
├── contacts.vue            // 联系人信息
├── dataOther.vue           // 其它资料列表
├── dataUpload.vue          // 其它资料上传(详情)
├── index.vue               // 首页
├── mobile.vue              // 手机认证
├── sbsqCity.vue            // 选择城市
├── sbsqLogin.vue           // 登录社保银行卡[未开发]
├── scan.vue                // 人脸识别[未开发]
├── supportBank.vue         // 查看支持银行
├── userInfo.vue            // 个人信息
├── waterBank.vue           // 流水-选择银行
├── waterLogin.vue          // 流水-登录[未开发]
├── work.vue                // 工作信息
├── zhima.vue               // 芝麻分

```
